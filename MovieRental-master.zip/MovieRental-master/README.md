# MovieRental
<hr>
This is an Information management application for a small DVD rental store that is just starting up.
